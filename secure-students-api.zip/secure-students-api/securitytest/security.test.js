const request = require("supertest");
const app = require("../Vulnerabilidades");
describe("Security Tests", () => {
  let adminToken = "";
  let studentToken = "";

  // Antes de correr los tests, hacemos login para obtener tokens reales
  beforeAll(async () => {
    const resAdmin = await request(app)
      .post("/api/login")
      .send({ email: "admin@school.com", password: "admin123" });
    adminToken = resAdmin.body.token;

    const resStudent = await request(app)
      .post("/api/login")
      .send({ email: "student@school.com", password: "student123" });
    studentToken = resStudent.body.token;
  });

  describe("SQL Injection Prevention", () => {
    it("should reject malicious SQL in student ID", async () => {
      const maliciousId = "1; DROP TABLE students; --";
      
      const res = await request(app)
        .get(`/api/students/${maliciousId}`)
        .set("Authorization", `Bearer ${adminToken}`);

      // El servidor debería devolver un 400 (Bad Request) o 404, pero NUNCA un 200 ni un 500 (crash)
      expect(res.status).not.toBe(200);
      expect(res.status).not.toBe(500);
    });

    it("should sanitize search queries", async () => {
      const maliciousQuery = "'; DROP TABLE users; --";
      
      const res = await request(app)
        .get(`/api/search?query=${maliciousQuery}`)
        .set("Authorization", `Bearer ${adminToken}`);

      // Debería devolver 200 con un array vacío (búsqueda segura que no encontró nada) o 400 (input rechazado)
      expect(res.status).toBeLessThan(500);
      if (res.status === 200) {
        expect(Array.isArray(res.body)).toBeTruthy();
      }
    });
  });

  describe("Access Control", () => {
    it("should require authentication for protected endpoints", async () => {
      // Intentamos hacer un DELETE sin enviar el header de Authorization
      const res = await request(app).delete("/api/students/1");
      
      // Debe rechazar la petición con un 401 Unauthorized
      expect(res.status).toBe(401);
    });

    it("should enforce role-based permissions", async () => {
      // Un estudiante intenta usar una ruta protegida (solo Admin debería poder borrar)
      const res = await request(app)
        .delete("/api/students/1")
        .set("Authorization", `Bearer ${studentToken}`);

      // Debe denegar el acceso con un 403 Forbidden
      expect(res.status).toBe(403);
    });
  });

  describe("Input Validation", () => {
    it("should reject invalid email formats", async () => {
      const res = await request(app)
        .put("/api/students/1")
        .set("Authorization", `Bearer ${adminToken}`)
        .send({
          name: "Juan Hacker",
          email: "correo-sin-formato-arroba",
          grade: 95.5
        });

      // Debe devolver 400 Bad Request por fallar la validación Joi
      expect(res.status).toBe(400);
    });

    it("should limit input lengths", async () => {
      const hugeName = "A".repeat(10000); // 10,000 caracteres para intentar causar un Buffer Overflow
      
      const res = await request(app)
        .put("/api/students/1")
        .set("Authorization", `Bearer ${adminToken}`)
        .send({
          name: hugeName,
          email: "juan@school.com",
          grade: 85.5
        });

      // Debe devolver 400 Bad Request indicando que el nombre es muy largo
      expect(res.status).toBe(400);
    });
  });

describe("Secure File Upload", () => {
    it("should sanitize filenames to prevent path traversal", async () => {
      const maliciousFilename = "../../../etc/passwd";
      const fileContent = "archivo malicioso";

      const res = await request(app)
        .post("/api/upload")
        .set("Authorization", `Bearer ${adminToken}`)
        .send({
          filename: maliciousFilename,
          content: fileContent
        });

      // Verificamos que el path resultante NO contenga los ".."
      // El código responde con: { message: "...", path: "..." }
      expect(res.status).toBe(200);
      expect(res.body.path).not.toContain(".."); 
      expect(res.body.path).toContain("passwd"); // El nombre se mantiene, pero la ruta es segura
      
      // Opcional: Verificar que se guardó en la carpeta uploads y no en la raíz
      expect(res.body.path).toMatch(/uploads[/\\]passwd$/);
    });
  });
});