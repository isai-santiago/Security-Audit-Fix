const winston = require("winston");

const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.Console()
  ],
});

const logSecurityEvent = (event, req, additionalData = {}) => {
  // Sanitizamos datos para no guardar contraseñas en los logs
  const sanitizedData = { ...additionalData };
  if (sanitizedData.password) delete sanitizedData.password;

  logger.info("SECURITY_EVENT", {
    event,
    ip: req.ip,
    method: req.method,
    endpoint: req.originalUrl,
    timestamp: new Date().toISOString(),
    ...sanitizedData
  });
};

module.exports = { logger, logSecurityEvent };