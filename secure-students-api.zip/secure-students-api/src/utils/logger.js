const winston = require("winston");

class SecurityLogger {
  constructor() {
    this.logger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.json() // Estructura JSON para fácil parsing
      ),
      defaultMeta: { service: 'students-api-security' },
      transports: [
        // Logs de errores críticos
        new winston.transports.File({ filename: 'logs/security-error.log', level: 'error' }),
        // Todos los eventos de seguridad
        new winston.transports.File({ filename: 'logs/security.log' }),
      ],
    });
  }

  // Método para sanitizar datos (remover secretos)
  sanitizeLogData(data) {
    if (!data) return {};
    const sanitized = { ...data };
    
    const sensitiveKeys = ['password', 'token', 'authorization', 'secret', 'credit_card'];
    
    Object.keys(sanitized).forEach(key => {
      if (sensitiveKeys.includes(key.toLowerCase())) {
        sanitized[key] = '[REDACTED]';
      }
    });
    return sanitized;
  }

  logSecurityEvent(event, req, additionalData = {}) {
    const sanitizedData = this.sanitizeLogData(additionalData);
    
    const logPayload = {
      event: event,
      ip: req.ip || req.connection.remoteAddress,
      userAgent: req.get('User-Agent'),
      method: req.method,
      url: req.originalUrl,
      userId: req.user ? req.user.userId : 'anonymous',
      data: sanitizedData
    };

    this.logger.info(logPayload);
  }
}

module.exports = new SecurityLogger();