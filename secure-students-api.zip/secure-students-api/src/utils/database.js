const mysql = require("mysql2/promise");
require('dotenv').config();

class DatabaseManager {
  constructor() {
    this.pool = mysql.createPool({
      host: process.env.DB_HOST,
      user: process.env.DB_USER,
      password: process.env.DB_PASSWORD,
      database: process.env.DB_NAME,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      // ssl: { rejectUnauthorized: true } // Descomentar en producción con SSL real
    });
  }

  async getStudentById(id) {
    try {
      // 1. Validar input antes de query
      if (isNaN(id)) {
        throw new Error("ID inválido");
      }

      // 2. Implementar query con prepared statements
      const [rows] = await this.pool.execute(
        "SELECT id, name, email, grade, role FROM users WHERE id = ?", 
        [id]
      );

      return rows[0];
    } catch (error) {
      // 3. Manejar errores sin exponer detalles de DB
      console.error("DB Error (getStudentById):", error.message);
      if (error.message === "ID inválido") return null;
      throw new Error("Error al recuperar datos del estudiante.");
    }
  }

  async updateStudent(id, data) {
    let connection;
    try {
      // Obtener una conexión dedicada para la transacción
      connection = await this.pool.getConnection();
      
      // 1. Iniciar Transacción (Atomicidad)
      await connection.beginTransaction();

      // Verificar existencia
      const [exists] = await connection.execute(
        "SELECT id FROM users WHERE id = ? FOR UPDATE", 
        [id]
      );

      if (exists.length === 0) {
        await connection.rollback();
        return null;
      }

      // Construcción dinámica de la query segura
      const fields = Object.keys(data);
      const values = Object.values(data);
      
      if (fields.length === 0) {
        await connection.rollback();
        return false;
      }

      // SET field1 = ?, field2 = ?
      const setClause = fields.map(field => `${field} = ?`).join(", ");
      
      // 2. Prepared statements
      await connection.execute(
        `UPDATE users SET ${setClause} WHERE id = ?`,
        [...values, id]
      );

      // 3. Commit
      await connection.commit();
      return true;

    } catch (error) {
      if (connection) await connection.rollback();
      console.error("DB Error (updateStudent):", error.message);
      throw new Error("Error al actualizar el estudiante.");
    } finally {
      if (connection) connection.release();
    }
  }
}

module.exports = new DatabaseManager();