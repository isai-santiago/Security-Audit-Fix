const express = require("express");
const helmet = require("helmet");
const cors = require("cors");
const rateLimit = require("express-rate-limit");
// ... imports de rutas ...

const app = express();

// 1. Configurar Helmet (CSP, HSTS, etc.)
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"], // Bloquear scripts inline
        objectSrc: ["'none'"], // Bloquear plugins como Flash
        upgradeInsecureRequests: [], // Forzar HTTPS
      },
    },
    hsts: {
      maxAge: 31536000, // 1 año
      includeSubDomains: true,
      preload: true,
    },
    frameguard: { action: 'deny' } // Prevenir Clickjacking
  })
);

// 2. Configurar CORS restrictivo
app.use(
  cors({
    origin: process.env.ALLOWED_ORIGIN || "http://localhost:3000", // Específico, NO '*'
    methods: ["GET", "POST", "PUT", "DELETE"],
    allowedHeaders: ["Content-Type", "Authorization"],
    credentials: true, // Solo si el frontend maneja cookies
    maxAge: 86400 // Cachear preflight requests por 1 día
  })
);

// 3. Configurar rate limiting para Login
const loginRateLimit = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 5, // Máximo 5 intentos fallidos
  standardHeaders: true,
  legacyHeaders: false,
  message: {
    error: "Demasiados intentos de inicio de sesión. Por favor intente nuevamente en 15 minutos."
  }
});

// Aplicar rate limit solo a la ruta de login
// app.post("/api/login", loginRateLimit, authController.login);