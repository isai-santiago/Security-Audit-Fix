const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const rateLimit = require("express-rate-limit");
const { logger } = require("./utils/logger");

const authRoutes = require("./routes/auth.routes");
const studentRoutes = require("./routes/student.routes");

const app = express();

// --- SECURITY MIDDLEWARES ---
app.use(helmet()); // Protege contra vulnerabilidades web conocidas seteando cabeceras HTTP
app.use(cors());
app.use(express.json({ limit: "10kb" })); // Previene ataques de denegación de servicio por payload gigante

// Limitar intentos de peticiones (Previene ataques de fuerza bruta)
const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // Límite de 100 peticiones por IP
  message: { error: "Demasiadas peticiones, intenta más tarde." }
});
app.use("/api/", apiLimiter);

// --- ROUTES ---
app.use("/api", authRoutes);
app.use("/api/students", studentRoutes);
// La búsqueda y upload están dentro de students.routes para mayor limpieza, 
// o puedes redirigirlas usando app.use("/api", studentRoutes) dependiendo de tu router.
app.use("/api", studentRoutes); // Mapea /api/search y /api/upload

// --- SERVER ---
if (require.main === module) {
  app.listen(3000, () => {
    logger.info("✅ Servidor SECURE-SDLC corriendo en el puerto 3000 con Cero Vulnerabilidades.");
  });
}

// EXPORTAR PARA SUPERTEST
module.exports = app;