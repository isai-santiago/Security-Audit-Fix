const jwt = require("jsonwebtoken");
const { promisify } = require("util");
require('dotenv').config();

const authenticateToken = async (req, res, next) => {
  try {
    // 1. Validar header Authorization
    const authHeader = req.headers['authorization'];
    let token;

    if (authHeader && authHeader.startsWith('Bearer ')) {
      token = authHeader.split(' ')[1];
    }

    if (!token) {
      return res.status(401).json({ 
        error: "Acceso denegado. Token no proporcionado o formato inválido." 
      });
    }

    // 2. Verificar token con secret desde env
    const secret = process.env.JWT_SECRET;
    if (!secret) {
        throw new Error("JWT_SECRET no está configurado en el entorno");
    }

    // Promisify jwt.verify para usar async/await
    const decoded = await promisify(jwt.verify)(token, secret);

    // 3. Adjuntar usuario al request
    req.user = decoded;
    next();

  } catch (error) {
    // 4. Manejar errores apropiadamente (No exponer detalles técnicos)
    if (error.name === 'JsonWebTokenError') {
      return res.status(403).json({ error: "Token inválido." });
    }
    if (error.name === 'TokenExpiredError') {
      return res.status(403).json({ error: "El token ha expirado." });
    }
    
    console.error("Error en autenticación:", error.message);
    return res.status(500).json({ error: "Error interno de autenticación." });
  }
};

const requireRole = (allowedRoles) => (req, res, next) => {
  // 1. Verificar que el usuario exista (pasó por authenticateToken)
  if (!req.user) {
    return res.status(401).json({ error: "Usuario no autenticado." });
  }

  // 2. Verificar que el usuario tenga rol requerido (Least Privilege)
  if (!allowedRoles.includes(req.user.role)) {
    return res.status(403).json({ 
      error: "Acceso prohibido. No tienes los permisos necesarios para esta acción." 
    });
  }

  next();
};

module.exports = { authenticateToken, requireRole };