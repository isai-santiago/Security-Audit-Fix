const jwt = require("jsonwebtoken");
const { logSecurityEvent } = require("../utils/logger");

const JWT_SECRET = "supersecret123"; // En producción debe ir en .env

const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    logSecurityEvent("MISSING_TOKEN", req);
    return res.status(401).json({ error: "Acceso denegado. Token requerido." });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      logSecurityEvent("INVALID_TOKEN", req);
      return res.status(403).json({ error: "Token inválido o expirado." });
    }
    req.user = user;
    next();
  });
};

const requireRole = (rolesPermitidos) => {
  return (req, res, next) => {
    if (!req.user || !rolesPermitidos.includes(req.user.role)) {
      logSecurityEvent("UNAUTHORIZED_ROLE_ATTEMPT", req, { userRole: req.user?.role });
      return res.status(403).json({ error: "Permisos insuficientes para esta acción." });
    }
    next();
  };
};

module.exports = { authenticateToken, requireRole };