const Joi = require("joi");
const { logSecurityEvent } = require("../utils/logger");

const validateStudentUpdate = (req, res, next) => {
  const schema = Joi.object({
    name: Joi.string().min(2).max(100).required(), // Bloquea el Buffer Overflow del Test 6
    email: Joi.string().email().required(),        // Bloquea correos falsos del Test 5
    grade: Joi.number().min(0).max(100).required()
  });

  const { error } = schema.validate(req.body);
  if (error) {
    logSecurityEvent("VALIDATION_FAILED", req, { details: error.details[0].message });
    return res.status(400).json({ error: error.details[0].message });
  }
  next();
};

const validateId = (req, res, next) => {
  const schema = Joi.number().integer().positive().required();
  const { error } = schema.validate(req.params.id);
  if (error) {
    logSecurityEvent("MALICIOUS_ID_ATTEMPT", req, { providedId: req.params.id });
    return res.status(400).json({ error: "ID inválido" }); // Bloquea inyección SQL en el ID
  }
  next();
};

module.exports = { validateStudentUpdate, validateId };