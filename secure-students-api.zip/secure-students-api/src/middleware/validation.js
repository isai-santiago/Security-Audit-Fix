const Joi = require("joi");

const validateStudentUpdate = (req, res, next) => {
  // 1. Definir validaciones estrictas
  const schema = Joi.object({
    name: Joi.string()
      .min(2)
      .max(50)
      .pattern(/^[a-zA-Z\s]+$/) // Solo letras y espacios
      .trim()
      .messages({
        'string.pattern.base': 'El nombre solo debe contener letras y espacios.',
        'string.empty': 'El nombre no puede estar vacío.'
      }),
    
    email: Joi.string()
      .email({ minDomainSegments: 2 })
      .lowercase()
      .messages({
        'string.email': 'Debe proporcionar un correo electrónico válido.'
      }),
    
    grade: Joi.number()
      .min(0)
      .max(100)
      .messages({
        'number.min': 'La calificación no puede ser menor a 0.',
        'number.max': 'La calificación no puede ser mayor a 100.'
      })
  }).min(1); // Al menos un campo debe estar presente para actualizar

  // 2. Validar y sanitizar input
  const { error, value } = schema.validate(req.body, {
    abortEarly: false, // Reportar todos los errores, no solo el primero
    stripUnknown: true // Sanitizar: Eliminar campos que no estén en el schema
  });

  if (error) {
    // Retornar errores descriptivos pero seguros
    const errorMessages = error.details.map(detail => detail.message);
    return res.status(400).json({ 
      error: "Datos de entrada inválidos", 
      details: errorMessages 
    });
  }

  // Reemplazar req.body con los datos sanitizados
  req.body = value;
  next();
};

module.exports = { validateStudentUpdate };