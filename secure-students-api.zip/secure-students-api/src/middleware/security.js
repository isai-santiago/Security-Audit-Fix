const rateLimit = require("express-rate-limit");
const securityConfig = require("../../config/security");

const apiLimiter = rateLimit(securityConfig.rateLimit);

module.exports = { apiLimiter };