const express = require("express");
const fs = require("fs");
const path = require("path");
const db = require("../utils/database");
const { logSecurityEvent } = require("../utils/logger");
const { authenticateToken, requireRole } = require("../middleware/auth");
const { validateStudentUpdate, validateId } = require("../middleware/validation");

const router = express.Router();

// Search students (Protegido con Prepared Statements)
router.get("/search", authenticateToken, async (req, res) => {
  try {
    const query = req.query.query || "";
    const searchQuery = "SELECT * FROM students WHERE name LIKE ?";
    const [results] = await db.execute(searchQuery, [`%${query}%`]);
    res.json(results);
  } catch (err) {
    res.status(500).json({ error: "Error interno" });
  }
});

// Get profile
router.get("/:id", authenticateToken, validateId, async (req, res) => {
  try {
    const [results] = await db.execute("SELECT * FROM students WHERE id = ?", [req.params.id]);
    res.json(results[0] || {});
  } catch (err) {
    res.status(500).json({ error: "Error interno" });
  }
});

// Update profile
router.put("/:id", authenticateToken, requireRole(['admin', 'teacher']), validateId, validateStudentUpdate, async (req, res) => {
  try {
    const { name, email, grade } = req.body;
    const query = "UPDATE students SET name = ?, email = ?, grade = ? WHERE id = ?";
    await db.execute(query, [name, email, grade, req.params.id]);
    res.json({ message: "Estudiante actualizado de forma segura" });
  } catch (err) {
    res.status(500).json({ error: "Update failed" });
  }
});

// Delete student (Admin ONLY)
router.delete("/:id", authenticateToken, requireRole(['admin']), validateId, async (req, res) => {
  try {
    await db.execute("DELETE FROM students WHERE id = ?", [req.params.id]);
    logSecurityEvent("STUDENT_DELETED", req, { targetId: req.params.id });
    res.json({ message: "Student deleted successfully" });
  } catch (err) {
    res.status(500).json({ error: "Delete failed" });
  }
});

// Secure Upload
router.post("/upload", authenticateToken, (req, res) => {
  const { filename, content } = req.body;
  if (!filename) return res.status(400).json({ error: "Filename es requerido" });

  // PATH TRAVERSAL FIX: path.basename elimina los "../" de las rutas maliciosas
  const safeFilename = path.basename(filename); 
  
  if (!fs.existsSync('./uploads')) fs.mkdirSync('./uploads');
  
  const finalPath = path.join(__dirname, '../../uploads', safeFilename);
  fs.writeFileSync(finalPath, content || "");
  
  res.json({ message: "File uploaded securely", path: finalPath });
});

module.exports = router;