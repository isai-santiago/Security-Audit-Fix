const express = require("express");
const jwt = require("jsonwebtoken");
const db = require("../utils/database");
const { logSecurityEvent } = require("../utils/logger");

const router = express.Router();
const JWT_SECRET = "supersecret123"; 

router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;

    // PREPARED STATEMENT: Los signos '?' evitan que el código SQL malicioso se ejecute
    const query = "SELECT * FROM users WHERE email = ? AND password = ?";
    const [results] = await db.execute(query, [email, password]);

    if (results.length > 0) {
      const user = results[0];
      const token = jwt.sign(
        { userId: user.id, email: user.email, role: user.role }, 
        JWT_SECRET, 
        { expiresIn: '1h' }
      );
      
      logSecurityEvent("LOGIN_SUCCESS", req, { email });
      res.json({ message: "Login successful", token, role: user.role });
    } else {
      logSecurityEvent("LOGIN_FAILED", req, { email });
      res.status(401).json({ error: "Invalid credentials" });
    }
  } catch (err) {
    res.status(500).json({ error: "Error interno" });
  }
});

module.exports = router;