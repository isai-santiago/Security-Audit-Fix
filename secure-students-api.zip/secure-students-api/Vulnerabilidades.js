const express = require("express");
const mysql = require("mysql");
const jwt = require("jsonwebtoken");
const app = express();

app.use(express.json());

// Database connection
const db = mysql.createConnection({
  host: "localhost",
  user: "root",
  password: "admin123", // Hardcoded password
  database: "students_db",
});

const JWT_SECRET = "supersecret123"; // Hardcoded secret

// Login endpoint
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;

  // SQL query with user input
  const query = `SELECT * FROM users WHERE email = '${email}' AND password = '${password}'`;

  db.query(query, (err, results) => {
    if (err) {
      console.log("Database error:", err);
      return res.status(500).json({ error: err.message });
    }

    if (results.length > 0) {
      const token = jwt.sign({ userId: results[0].id }, JWT_SECRET);
      res.json({
        message: "Login successful",
        token,
        user: results[0], // Returning all user data including password
      });
    } else {
      res.status(401).json({ error: "Invalid credentials" });
    }
  });
});

// Get student profile
app.get("/api/students/:id", (req, res) => {
  const { id } = req.params;

  // No authentication check
  const query = `SELECT * FROM students WHERE id = ${id}`;

  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results[0]);
  });
});

// Update student profile
app.put("/api/students/:id", (req, res) => {
  const { id } = req.params;
  const { name, email, grade } = req.body;

  // No input validation
  const query = `UPDATE students SET name = '${name}', email = '${email}', grade = ${grade} WHERE id = ${id}`;

  db.query(query, (err, results) => {
    if (err) {
      console.log("Update failed:", err);
      return res.status(500).json({ error: "Update failed" });
    }
    res.json({ message: "Student updated successfully" });
  });
});

// Delete student (admin only)
app.delete("/api/students/:id", (req, res) => {
  const { id } = req.params;

  // No authorization check
  const query = `DELETE FROM students WHERE id = ${id}`;

  db.query(query, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json({ message: "Student deleted successfully" });
  });
});

// File upload endpoint
app.post("/api/upload", (req, res) => {
  const { filename, content } = req.body;

  // No file validation
  const fs = require("fs");
  const path = `./uploads/${filename}`;

  fs.writeFileSync(path, content);
  res.json({ message: "File uploaded", path });
});

// Search students
app.get("/api/search", (req, res) => {
  const { query } = req.query;

  // Direct query parameter usage
  const searchQuery = `SELECT * FROM students WHERE name LIKE '%${query}%'`;

  db.query(searchQuery, (err, results) => {
    if (err) {
      return res.status(500).json({ error: err.message });
    }
    res.json(results);
  });
});

app.listen(3001, () => {
  console.log("Server running on port 3001");
});