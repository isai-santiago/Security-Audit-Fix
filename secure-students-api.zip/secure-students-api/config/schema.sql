CREATE DATABASE students_db;
USE students_db;

CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(255) UNIQUE,
    password VARCHAR(255), -- Plain text passwords!
    role ENUM('student', 'teacher', 'admin') DEFAULT 'student',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100),
    email VARCHAR(255),
    grade DECIMAL(3,2),
    user_id INT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Sample data with plain text passwords
INSERT INTO users (email, password, role) VALUES
('admin@school.com', 'admin123', 'admin'),
('teacher@school.com', 'teacher123', 'teacher'),
('student@school.com', 'student123', 'student');

INSERT INTO students (name, email, grade, user_id) VALUES
('Juan Pérez', 'juan@school.com', 85.5, 3),
('María García', 'maria@school.com', 92.0, 3);